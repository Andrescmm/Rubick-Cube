#ifndef COLOR_H
#define COLOR_H
// Names the colors of the cube facelets
typedef enum {U, R, F, D, L, B} color_t;

#define COLOR_COUNT 6
#endif
